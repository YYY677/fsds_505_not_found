# FSDS
1-CASA0013 Foundations of Spatial Data Science
